#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double value;
    value = 5;
    cout << sqrt(value) << endl;
    cout << exp(value) << endl;
    cout << log10(value) << endl;
    cout << cos(value) << endl;

    return 0;
}